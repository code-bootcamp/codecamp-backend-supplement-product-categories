export interface IProductsCategoriesServiceCreate {
  name: string;
}
